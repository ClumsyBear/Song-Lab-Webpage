c *******************************************************************************
c *                   GDEP. This version 2.0 Oct 31, 2008                       *
c * This FORTRAN program is used to compute transition dependency:              *
c * A gene-gene interaction measure for times series microarray data            *
c * Reference: Xin Gao, Daniel Q. Pu, Peter X-K. Song                           *
c * EURASIP Journal on Bioinformatics and System Biology(2008)                  *
c * This program is written by Daniel Q. Pu, Xin Gao, Peter X-K. Song           *
c * Comments and suggestions are welcome                                        *
c * Please cite the reference source for any usage of this program              *
c * This program also cites certain subroutine from RANLIB                      *
c * Library of Fortran Routines for Random Number Generation                    *
c * The corresponding author and references have been cited in the program      *
c *                                                                             *
c * XIN GAO, Department of Mathematics and Statistics, York University          *
c * xingao@mathstat.yorku.ca                                                    *
c * DANIEL Q. PU                                                                *
c * Fraud Loss Prevention&Investigation, Fraud Control, CIBC, Toronto, CA       *
c * qiang.pu@cibc.com                                                           *
c * Peter X-K. Song                                                             *
c * Department of Biostatistics, University of Michigan School of Public Health *
c * pxsong@umich.edu                                                            *
c *                                                                             *
c * Input:                                                                      *
c * "realdata.txt" is the dataset with format(T*REP,Ngene);                     *
c * "para1.txt" includes the mean and std with format(2, Ngene);                *
c * "para2.txt" includes the mean and std with format(2, Ngene);                *
c *                                                                             *
c * Output: "output.txt" and "pvalue.txt"                                       *
c * "output.txt" includes the following information:                            *
c * nullstat: includes the Boot-strap value under null based on proposed method;*
c * nullcorr: includes the Boot-strap value under null with correlation method; *
c * "pvalue.txt" includes the following information:                            *
c * observerd statistic with proposed method;                                   *    
c * pvalue of each pair based on our proposed method;                           *
c * observerd statistic with correlation method;                                *    
c * pvalue of each pair based on correlation method;                            *
c *******************************************************************************

"GDEPver20.f" is the version 2.0, which is improved version of GDEP version 1.0.
This version is library free program, unlike version 1.0 we need IMSL library. 
"GDEPver20" is executable file of GDEPver20.f;

The source code can be compiled by either "ifort" or "gfortran". 
ifort's version is "ifort (IFORT) 9.0  20050430".
gfortran's version is "GNU Fortran (GCC) 4.1.2 20071124 (Red Hat 4.1.2-42)."

The executable files are tested on a PC running Linux ("uname -a" output: "Linux titan.math.yorku.ca 2.6.9-67.0.15.ELsmp i686 i686 i386 GNU/Linux").

The following shows how to complie and to run GEDP program, 
and the results from the reference are based on the following parameters,
and it takes about 40 minutes (depending on the CPU):

$ ifort -o GDEPver20 GDEPver20.f 
(or $gfortran -o GDEPver20 GDEPver20.f -O3)
$ ./GDEPver20
  Probability density is gene index or time index?
 (G: gene index; T: time index)
 G
 Input time points:
 10
 Input the number of replicates:
 44
 Input the number of boot strap:
 100
 Input the number of genes:
 55
 The program is running, please wait...

With the above setting, the values in the first few lines in the "pvalue.txt" file should be close to   
 Gene1    Gene2    observed stat new    newpvalue    observed stat corr    corrvalue
   1         2       28.70365684        0.35114479        0.17228352       0.49644443
   1         3       16.68756063        0.49497643        0.26933096       0.34404713
   1         4      150.39897345        0.04837710        0.14503336       0.55001348
   1         5      198.49374462        0.02789226        0.65605011       0.04484848
   1         6        3.95154040        0.71546125        0.50872468       0.09357576
   1         7      381.78291308        0.00452525        0.33205091       0.26339394
   1         8       42.63614283        0.25055218        0.42164810       0.16674748

Notes:
1. Users should deploy all the data files under the same directory where the executable file is located.
2. Before launching the program, please delete/rename the files (under the directory where GDEPver20) whose names are "pvalue.txt" and "output.txt".
 