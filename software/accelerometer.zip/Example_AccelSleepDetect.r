## To install AccelSleepDetect_1.0.tar.gz in R 3.3.0, dependencies should be installed. 
install.packages(c("devtools", "installr", "changepoint", "accelerometry"))
library(devtools)
install_github("twitter/BreakoutDetection", force=TRUE)
install_github("masalmon/convertagd", force=TRUE)
## to install flsa, use local zip file, flsa_1.05.tar.gz ##
# if Rtools is not installed in your computer # 
#install.Rtools()
## install AccelSleepDetect from the local zip file ##


library(AccelSleepDetect)
dir_dat = "C:\\Users\\BaekJ\\Box Sync\\AccelerometerSleepEstimation\\Rcode\\ExampleRCode\\"
dataout = read.csv(paste(dir_dat, "ExampleAccelFile.csv", sep=""), header = TRUE)

diary = data.frame(bed = "2015-04-16 00:30:00", wake = "2015-04-16 06:00:00")
diary[,1] = as.POSIXct(diary[,1], tz = "GMT", format="%Y-%m-%d %H:%M:%S")
diary[,2] = as.POSIXct(diary[,2], tz = "GMT", format="%Y-%m-%d %H:%M:%S")

### Proposed FLASSO and OP(PELT) for sleep detection without sleep diary (the default sleep on/off was set between 22:00:00 and 8:00:00) ###
FitFLASSO = SleepEstEachDay(dataout, Method="FLASSO",
							   id = "00xx",
							   Y_name = "VM", Y_threshold = 0,   
							   NoPA_cut = .5,
							   N_steps = 50,
							   sleep_mins = 5, 
							   nap_mins = 20,
							   NoPA_cut_adapt = TRUE,
							   UseDiary = FALSE,
							   tz = "GMT",
							   visual=TRUE)		
								  
FitPELT = SleepEstEachDay(dataout, Method="PELT",
							   id = "00xx",
							   Y_name = "VM", Y_threshold = 0,   
							   NoPA_cut = .5,
							   N_steps = 50,
							   sleep_mins = 5, 
							   nap_mins = 20,
							   NoPA_cut_adapt = TRUE,
							   UseDiary = FALSE,
							   tz = "GMT",
							   visual=TRUE)		
FitFLASSO$summary_sleep								  
FitPELT$summary_sleep

plot.eachday(FitFLASSO, ylab = "VM", xlab = "Date")
plot.eachday(FitPELT, ylab = "VM", xlab = "Date")


### Proposed FLASSO for sleep detection with diary ###
FitFLASSO2 = SleepEstEachDay(dataout, Method="FLASSO",
							   id = "0066",
							   Y_name = "VM", Y_threshold = 0,   
							   NoPA_cut = .5,
							   N_steps = 50,
							   sleep_mins = 5, 
							   nap_mins = 20,
							   NoPA_cut_adapt = TRUE,
							   UseDiary = TRUE,
							   diary_data = diary, 
							   tz = "GMT",
							   visual=TRUE)		
								  
### Proposed OP(PELT) for sleep detection ###
FitPELT2 = SleepEstEachDay(dataout, Method="PELT",
							   id = "0066",
							   Y_name = "VM", Y_threshold = 0,   
							   NoPA_cut = .5,
							   N_steps = 50,
							   sleep_mins = 5, 
							   nap_mins = 20,
							   NoPA_cut_adapt = TRUE,
							   UseDiary = TRUE,
							   diary_data = diary, 
							   tz = "GMT",
							   visual=TRUE)		
FitFLASSO2$summary_sleep								  
FitPELT2$summary_sleep


plot.eachday(FitFLASSO2, ylab = "VM", xlab = "Date")
plot.eachday(FitPELT2, ylab = "VM", xlab = "Date")


