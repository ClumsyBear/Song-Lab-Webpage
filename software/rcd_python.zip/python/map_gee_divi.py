#!/sw/lsa/centos7/python-anaconda2/201607/bin/python
# #!/usr/bin/env python
import fileinput
import statsmodels.api as sm
import statsmodels.formula.api as smf
import numpy as np

X_dict = {}
Y_dict = {}
sub_dict = {}
size_dict = {}
fit_coef = {}
fit_covinv = {}
p = 16
fam = sm.families.Binomial()
ind = sm.cov_struct.Exchangeable()
    

for line in fileinput.input():
    rowitems = line.split()
    key = str(rowitems[-1])
    for word in key:
        if len(word) > 0:
            if word not in Y_dict.keys():
                X_dict[word] = map(float, rowitems[1:-3])
                Y_dict[word] = [float(rowitems[0])]
                sub_dict[word] = [int(rowitems[-3])]
                size_dict[word] = 1
            else:
                X_dict[word].extend(map(float, rowitems[1:-3]))
                Y_dict[word].extend([float(rowitems[0])])
                sub_dict[word].extend([int(rowitems[-3])])
                size_dict[word] = size_dict[word] + 1
for word in Y_dict.keys():
    X_dict[word] = np.array(X_dict[word]).reshape((size_dict[word], p))
    Y_dict[word] = np.array(Y_dict[word])
    sub_dict[word] = np.array(sub_dict[word])
    results = sm.GEE(Y_dict[word], X_dict[word], sub_dict[word], family = fam, cov_struct = ind)
    res = results.fit()
    fit_coef[word] = res.params
    fit_covinv[word] = np.linalg.inv(res.cov_params())
    print str(word) + '\t' + 'e' + '\t' + '\t'.join(map(str, fit_coef[word]))    
    row_count = 0
    for row in fit_covinv[word]:
        print str(word) + '\t' + str(row_count) + '\t' + '\t'.join(map(str, row))
        row_count +=1     