#!/sw/lsa/centos7/python-anaconda2/201607/bin/python
# #!/usr/bin/env python
import fileinput
import statsmodels.api as sm
import statsmodels.formula.api as smf
import numpy as np

beta_dict = {}
var_dict = {}
var_id = {}

for line in fileinput.input():
    rowitems = line.rstrip('\n').split('\t')
    if rowitems[1] == 'e':
        p = len(rowitems[2:])
        beta_dict[rowitems[0]] = map(float, rowitems[2:])
    elif int(rowitems[1]) == 15:
        var_dict[rowitems[0]] = map(float, rowitems[1:])
    else:
        var_dict[rowitems[0]].extend(map(float, rowitems[1:]))

sigbeta_sum = np.array([0.] * p)
sigma_sum = np.zeros((p,p))

for sid in beta_dict.keys():
    beta_dict[sid] = np.array(beta_dict[sid])
    var_dict[sid] = np.array(var_dict[sid]).reshape((p, p+1))
    var_dict[sid] = var_dict[sid][var_dict[sid][:,0].argsort()]
    var_dict[sid] = np.delete(var_dict[sid],np.s_[0:1],axis = 1)
    sigbeta_sum = sigbeta_sum + np.dot(beta_dict[sid], var_dict[sid])
    sigma_sum = sigma_sum + var_dict[sid]

beta_hat = np.dot(np.linalg.inv(sigma_sum), sigbeta_sum)
var_hat = np.linalg.inv(sigma_sum)
print beta_hat
print var_hat.diagonal()
print var_hat